<?php
define("ROW_PER_PAGE",500);
require_once('db.php');
session_start();

//to delete
if(isset($_POST['delete_info']))
{
    $id = $_POST['delete_info'];

    try {

        $query = "DELETE FROM hot_connect WHERE id=:id";
        $statement = $pdo_conn->prepare($query);
        $data = [
            ':id' => $id
        ];
        $query_execute = $statement->execute($data);

        if($query_execute)
        {
            $_SESSION['message'] = "Deleted Successfully";
            header('Location: index.php');
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "Not Deleted";
            header('Location: index.php');
            exit(0);
        }

    } catch(PDOException $e){
        echo $e->getMessage();
    }
}

?>
<html>
<head>
<style>
body{background-color:rgb(30,30,30); color:orange; width:100%;font-family:arial;letter-spacing:1px;line-height:20px;}
.tbl-qa{width: 99%;font-size:0.9em;background-color: rgb(20,20,20);}
.tbl-qa th.table-header {position:sticky; top:0; background-color:blue; color:white; padding: 5px;text-align: left;padding:10px;}
.tbl-qa .table-row td {padding:10px;background-color: rgb(30,30,30);vertical-align:top;}
.button_link {color:#FFF;text-decoration:none; background-color:#428a8e;padding:10px;}
#keyword{border: #CCC 1px solid; border-radius: 4px; padding: 7px;background:url("demo-search-icon.png") no-repeat center right 7px;}
.btn-page{margin-right:10px;padding:5px 10px; border: #CCC 1px solid; background:#FFF; border-radius:4px;cursor:pointer;}
.btn-page:hover{background:#F0F0F0;}
.btn-page.current{background:#F0F0F0;}
</style>
    <title>AIRTALK MOBILE</title>
      <link rel="icon" type="image/x-icon" href="Screenshot%202023-10-08%20195549.png">
<!--    <link rel="stylesheet" href="./assets/css/style.css">-->
</head>
<body>
<?php	
	$search_keyword = '';
	if(!empty($_POST['search']['keyword'])) {
		$search_keyword = $_POST['search']['keyword'];
	}
	$sql = 'SELECT * FROM hot_connect WHERE pid LIKE :keyword OR sr LIKE :keyword OR area LIKE :keyword OR plan LIKE :keyword OR hotspot LIKE :keyword ORDER BY id  ';
	
	/* Pagination Code starts */
	$per_page_html = '';
	$page = 1;
	$start=0;
	if(!empty($_POST["page"])) {
		$page = $_POST["page"];
		$start=($page-1) * ROW_PER_PAGE;
	}
	$limit=" limit " . $start . "," . ROW_PER_PAGE;
	$pagination_statement = $pdo_conn->prepare($sql);
	$pagination_statement->bindValue(':keyword', '%' . $search_keyword . '%', PDO::PARAM_STR);
	$pagination_statement->execute();

	$row_count = $pagination_statement->rowCount();
	if(!empty($row_count)){
		$per_page_html .= "<div style='text-align:center;margin:20px 0px;'>";
		$page_count=ceil($row_count/ROW_PER_PAGE);
		if($page_count>1) {
			for($i=1;$i<=$page_count;$i++){
				if($i==$page){
					$per_page_html .= '<input type="submit" name="page" value="' . $i . '" class="btn-page current" />';
				} else {
					$per_page_html .= '<input type="submit" name="page" value="' . $i . '" class="btn-page" />';
				}
			}
		}
		$per_page_html .= "</div>";
	}
	
	$query = $sql.$limit;
	$pdo_statement = $pdo_conn->prepare($query);
	$pdo_statement->bindValue(':keyword', '%' . $search_keyword . '%', PDO::PARAM_STR);
	$pdo_statement->execute();
	$result = $pdo_statement->fetchAll();
?>
    
<form name='frmSearch' action='' method='post'>
<iframe style="border:none; width:98%; height:50;" src="insert.php" title="description"></iframe>
    <h3 style="color:white;">SEARCH</h3><input type='text' style="background-color:ghostwhite;" float-end name='search[keyword]' value="<?php echo $search_keyword; ?>" id='keyword' maxlength='25'>
<iframe align="right" style="border:none; height:10%; color:white;" src="count.php" title="description"></iframe>
    <table class='tbl-qa'>
  <thead>
	<tr>
	  <th class='table-header' width='20%'>PID</th>
	  <th class='table-header' width='20%'>SR</th>
	  <th class='table-header' width='20%'>AREA</th>
	  <th class='table-header' width='20%'>PLAN</th>
	  <th class='table-header' width='10%'>HOTSPOT</th>
	  <th class='table-header' width='20%'>ACTION</th>
	</tr>
  </thead>
  <tbody id='table-body'>
	<?php
	if(!empty($result)) { 
		foreach($result as $row) {
	?>
	  <tr class='table-row'>
		<td><?php echo $row['pid']; ?></td>
		<td><?php echo $row['sr']; ?></td>
		<td><?php echo $row['area']; ?></td>
		<td><?php echo $row['plan']; ?></td>
		<td><?php echo $row['hotspot']; ?></td>
          <td>         
            <form action="index.php" method="POST">
            <button><a href="edit.php?id=<?= $row['id']; ?>" class="">...</a></button>
            <button type="submit" name="delete_info" value="<?=$row['id'];?>" 
                    class="delete">X</button>
            </form></td>
	  </tr>
    <?php
		}
	}
	?>
  </tbody>
</table>
<?php echo $per_page_html; ?>
</form>
<!--
    <script type="text/javascript" src="./assets/js/ajaxWork.js"></script>    
    <script type="text/javascript" src="./assets/js/script.js"></script>
-->
</body>
</html>